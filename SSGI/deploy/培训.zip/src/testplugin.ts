@VREdit.installPlugin
// 该案例需要上传图片到资源区，压缩包自带两张，可直接上传使用
class testPlugin extends VREdit.Iplugin {
    public id: string = "test";
    public dependence = ["test"];
    public mesh:VREdit.IEDMesh
    // 创建变量用来保存result
    public testData;
    public button: VREdit.IButton[] = [
        {
            img: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAOlJREFUSEvNluERwiAMRmEEMpEOoUPqEHaiMAI9POFigfql3MX2Z4G+JH0BvDN+vDHPHQLGGB850BDCXRuwGphhKaVbBnnvn1qoCihhJTMtFAb2YEegEHAPpoVCQCkGM7+cc5fPu4WIrhpxzgPMZewZiGQ4Wvs2u1eO8s+IqBlHgMycRvY2H5SCzABHffoF7Ni4DISo0vwYbzaHCkTU19go58ry/g+YIzItaSmBqTRb6IylcFtIqFnj79mINP7e+vPspTJKpEfRgxjO0PQA7rWM9uCt87XbleklSmZqdk3UVmQ7H5ZmFlTWr9J/3h12uQ9QAAAAAElFTkSuQmCC",
            enable: (entity: VREdit.IEDEntity) => {
                const title="创建"

                const test = new xunbaoWindow(title, this);
            },
            disable: () => {
                
            },
            mutex: VREdit.MutexMode.self, //VREdit.MutexMode.global
            mode: VREdit.ClickMode.normal,
            active: false,
            tips: "这是一个宝藏按钮",
        },
        
    ];
    public init(entity: VREdit.IEDEntity) {

    }
    // 当选择一个左侧对象树物体的时候，把所有的des的值都改成选择物体的name
    public onEntityPick(mesh: VREdit.IEDEntity) {
        if (mesh instanceof VREdit.IEDMesh) {
            this.mesh = mesh
        }
    }
    public onAssetPick(asset: VREdit.IEDAsset) {

    }

    public extends = {

    };

    public uninstall() {

    }
}

class xunbaoWindow extends VREdit.Window {
    private testData = [];
    private Iplugin:testPlugin
    constructor(title: string, Iplugin?: testPlugin) {
        super(title, {
            drag: false,
            width: 258,
            height: "644px",
            position: "top-right",
            maxHeight: "547px",
            contentHeight: "547px",
            closeMode: "confirm",
        });
        
        // 创建UI
        let json = {
            scale: {
                type: "vector3",
                name: "大小",
            },
            des:{
                type:"string",
                name:"描述",
                value:"zhizhizhi"
            },
            Number:{
                type:"NumberField",
                name:"数字输入框",
                value:5555
            }
        };
       const allMesh  =  VREdit.shareBox.id2Entity
       console.log(allMesh);
        this.Iplugin = Iplugin
        let result = this.json2Content(json);
        // 创建数据
        Iplugin.testData = result;
        /**
         *
         * @param path 触发数据改变的位置
         * @param val 改变的数据
         * @param isDelete 是否是在删除数据
         */

        result.onchange = async (path, val, isDelete) => {
           
            if(path==="Number"){
                console.log(val);
                
            }
            if(path==="scale"){
                
                Iplugin.mesh.scale  = val
                console.log(Iplugin.mesh);
            }

        };
        
    }
    protected closeActList: (() => void)[];
    protected confirmActList = [()=>{
        const table = this.Iplugin.createTable("表格")
        table.table[0][0] = "hahahh"
        table.updateTable()
    }];
}
